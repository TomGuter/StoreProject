module.exports = {
    database: 'mongodb+srv://gutertom2:jrtk0718@cluster0.ywt2upm.mongodb.net/'
}